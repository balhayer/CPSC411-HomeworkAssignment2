# Home_work_Assignment_part_1
Open project in Android Studio
Run in emulator.
Below are the images of the assignment.


![alt text](Screenshot_1571448371.png)
![alt text](Screenshot_1571448377.png)
![alt text](Screenshot_1571448390.png)
