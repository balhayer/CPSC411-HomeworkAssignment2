package com.hayer.android.assn2_studentcourse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hayer.android.assn2_studentcourse.model.CourseEnrollment;
import com.hayer.android.assn2_studentcourse.model.Student;
import com.hayer.android.assn2_studentcourse.model.StudentDB;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    protected LinearLayout root;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createStudents();
        setContentView(R.layout.student_summary);

        root = findViewById(R.id.student_summary);

        ArrayList<Student> studList = StudentDB.getInstance().getStudents();
        for (int i=0; i<studList.size(); i++) {
            Student s = studList.get(i);
            LayoutInflater inflater = LayoutInflater.from(this);
            View row_view = inflater.inflate(R.layout.student_row, root, false);
            TextView firstNameView = (TextView) row_view.findViewById(R.id.first_name);
            firstNameView.setText(s.getFirstName());
            TextView lastNameView = (TextView) row_view.findViewById(R.id.last_name);
            lastNameView.setText(s.getLastName());
            root.addView(row_view);
        }

    }

    protected void createStudents() {
        Student studentOne = new Student("Balwinder", "Hayer", 888976262);
        ArrayList<CourseEnrollment> courses = new ArrayList<>();
        courses.add(new CourseEnrollment("CPSC-474","B"));
        courses.add(new CourseEnrollment("CPSC-323","C"));
        courses.add(new CourseEnrollment("CPSC-335","B"));
        studentOne.setCourses(courses);

        Student studentTwo = new Student("Micheal", "Edwards", 897968342);
        courses = new ArrayList<>();
        courses.add(new CourseEnrollment("CPSC-323","B"));
        courses.add(new CourseEnrollment("CPSC-411","A"));
        studentTwo.setCourses(courses);

        Student studentThree = new Student("Angelina", "Jolley", 887867563);
        courses = new ArrayList<>();
        courses.add(new CourseEnrollment("CPSC-474","B"));
        courses.add(new CourseEnrollment("CPSC-411","A"));
        studentThree.setCourses(courses);

        ArrayList<Student> studList = new ArrayList<>();
        studList.add(studentOne);
        studList.add(studentTwo);
        studList.add(studentThree);

        StudentDB.getInstance().setStudents(studList);
    }
}
