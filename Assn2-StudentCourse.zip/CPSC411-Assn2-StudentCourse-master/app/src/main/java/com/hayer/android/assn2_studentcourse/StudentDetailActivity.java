package com.hayer.android.assn2_studentcourse;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toolbar;

import com.hayer.android.assn2_studentcourse.adapter.CoursesLVAdapter;
import com.hayer.android.assn2_studentcourse.adapter.SummaryLVAdapter;
import com.hayer.android.assn2_studentcourse.model.CourseEnrollment;
import com.hayer.android.assn2_studentcourse.model.Student;
import com.hayer.android.assn2_studentcourse.model.StudentDB;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class StudentDetailActivity extends AppCompatActivity {
    protected Toolbar mToolbar;
    protected ListView studentCourses;
    protected Student studentObject;
    protected CoursesLVAdapter ad;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final int studInd = getIntent().getIntExtra("StudentIndex", -1);

        setContentView(R.layout.activity_student_detail);
        final EditText firstNameView = (EditText) findViewById(R.id.first_name_val_id);
        final EditText lastNameView = (EditText) findViewById(R.id.last_name_val_id);
        final EditText cwidView = (EditText) findViewById(R.id.cwid_val_id);



        mToolbar = findViewById(R.id.toolbar);
        setActionBar(mToolbar);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setDisplayShowHomeEnabled(true);
        TextView tb_title = findViewById(R.id.title);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                finish();
            }
        });

        if (studInd >= 0){
            tb_title.setText("Edit Student");
            studentObject = StudentDB.getInstance().getStudents().get(studInd);
        } else {
            tb_title.setText("Add Student");
            studentObject = new Student();
            CourseEnrollment c = new CourseEnrollment("","");
            studentObject.addCourse(c);
        }

        // It sets the course information
        studentCourses = findViewById(R.id.courses_list);
        ad = new CoursesLVAdapter(studentObject);
        studentCourses.setAdapter(ad);

        // It creates the course button
        Button add_course_btn = findViewById(R.id.add_course_btn);
        add_course_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                studentObject.addCourse(new CourseEnrollment("",""));
                ad.notifyDataSetChanged();
            }
        });

        // It records and set student information
        if (studInd < 0) {
            firstNameView.setText("");
            lastNameView.setText("");
            cwidView.setText("");
        } else {

            firstNameView.setText(studentObject.getFirstName());
            lastNameView.setText(studentObject.getLastName());
            cwidView.setText(Integer.toString(studentObject.getCWID()));
        }

        // it displays done button
        Button done_btn = findViewById(R.id.add_btn);
        done_btn.setText("Done!");
        done_btn.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (studInd < 0) {
                        // It updates entered new Student
                        String fName = firstNameView.getText().toString();
                        String lName = lastNameView.getText().toString();
                        int cwid = Integer.parseInt(cwidView.getText().toString());
                        studentObject.set(fName, lName, cwid);
                        // It adds courses to the list

                        // It adds students to the database
                        ArrayList<Student> studList = StudentDB.getInstance().getStudents();
                        studList.add(studentObject);
                        StudentDB.getInstance().setStudents(studList);
                    } else {
                        // It updates existing present student information
                        String fName = firstNameView.getText().toString();
                        String lName = lastNameView.getText().toString();
                        int cwid = Integer.parseInt(cwidView.getText().toString());
                        studentObject.set(fName, lName, cwid);
                        StudentDB.getInstance().getStudents().set(studInd, studentObject);
                    }
                    onBackPressed();
                    finish();
                }
            }
        );





    }

}
